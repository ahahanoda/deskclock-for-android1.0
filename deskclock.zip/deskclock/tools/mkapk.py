#!/usr/bin/env python3
"""
Android 1.0 (API 1) 向けに、できるだけ「当時の jarsigner が作った形」に近い APK を組み立てる。

 - AndroidManifest.xml は aapt が作ったバイナリXMLを取り込む
   (--clean-manifest で、新しい aapt が足す compileSdkVersion 等の属性を取り除く)
 - zip エントリは全て一般目的ビットフラグ 0・通常のdeflate
 - 署名は v1 (JAR署名) のみ・SHA1 ダイジェスト・SHA1withRSA。v2/v3 の署名ブロックは付けない
"""
import argparse
import base64
import hashlib
import os
import struct
import subprocess
import sys
import zipfile

DROP_ATTRS = {
    "compileSdkVersion",
    "compileSdkVersionCodename",
    "platformBuildVersionCode",
    "platformBuildVersionName",
}


# ---------------------------------------------------------------- binary XML

def parse_axml(data):
    t, hs, sz = struct.unpack("<HHI", data[:8])
    if t != 0x0003:
        raise ValueError("not a binary XML file")
    strings, resids, events = [], [], []

    def s(i):
        return None if i < 0 else strings[i]

    o = 8
    while o < len(data):
        t, hs, sz = struct.unpack("<HHI", data[o:o + 8])
        if t == 0x0001:
            sc, stc, fl, so, sto = struct.unpack("<IIIII", data[o + 8:o + 28])
            if fl & 0x100:
                raise ValueError("UTF-8 string pool is not supported by this tool")
            offs = struct.unpack("<%dI" % sc, data[o + 28:o + 28 + 4 * sc])
            for off in offs:
                p = o + so + off
                n = struct.unpack("<H", data[p:p + 2])[0]
                strings.append(data[p + 2:p + 2 + 2 * n].decode("utf-16le"))
        elif t == 0x0180:
            n = (sz - 8) // 4
            resids = list(struct.unpack("<%dI" % n, data[o + 8:o + 8 + 4 * n]))
        elif t in (0x0100, 0x0101):
            line, cmt, prefix, uri = struct.unpack("<Iiii", data[o + 8:o + 24])
            events.append(("nss" if t == 0x0100 else "nse", line, s(prefix), s(uri)))
        elif t == 0x0102:
            line, cmt, ns, name, astart, asize, acount, idi, ci, si = struct.unpack(
                "<IiiiHHHHHH", data[o + 8:o + 36])
            attrs = []
            base = o + 16 + astart
            for i in range(acount):
                ans, an, raw, vsize, res0, vt, vd = struct.unpack(
                    "<iiiHBBI", data[base + i * asize:base + i * asize + 20])
                val = strings[vd] if vt == 0x03 else vd
                attrs.append((s(ans), s(an), s(raw), vt, val))
            events.append(("start", line, s(ns), s(name), attrs))
        elif t == 0x0103:
            line, cmt, ns, name = struct.unpack("<Iiii", data[o + 8:o + 24])
            events.append(("end", line, s(ns), s(name)))
        else:
            raise ValueError("unknown chunk 0x%x" % t)
        o += sz

    name_ids = {}
    for i, rid in enumerate(resids):
        name_ids[strings[i]] = rid
    return events, name_ids


def build_axml(events, name_ids):
    pool, idx = [], {}

    def sid(x):
        if x is None:
            return -1
        if x not in idx:
            idx[x] = len(pool)
            pool.append(x)
        return idx[x]

    # 先頭にリソースID付きの属性名を並べる(リソースマップと対応させるため)
    for e in events:
        if e[0] == "start":
            for (ns, name, raw, vt, vd) in e[4]:
                if name in name_ids:
                    sid(name)
    n_res = len(pool)
    resmap = [name_ids[pool[i]] for i in range(n_res)]

    body = bytearray()
    for e in events:
        kind = e[0]
        if kind in ("nss", "nse"):
            _, line, prefix, uri = e
            body += struct.pack("<HHIIiii", 0x0100 if kind == "nss" else 0x0101,
                                16, 24, line, -1, sid(prefix), sid(uri))
        elif kind == "start":
            _, line, ns, name, attrs = e
            n = len(attrs)
            body += struct.pack("<HHIIiiiHHHHHH", 0x0102, 16, 36 + 20 * n, line, -1,
                                sid(ns), sid(name), 0x14, 0x14, n, 0, 0, 0)
            for (ans, an, raw, vt, vd) in attrs:
                data = sid(vd) if vt == 0x03 else vd
                body += struct.pack("<iiiHBBI", sid(ans), sid(an),
                                    sid(raw) if raw is not None else -1,
                                    8, 0, vt, data)
        else:  # end
            _, line, ns, name = e
            body += struct.pack("<HHIIiii", 0x0103, 16, 24, line, -1, sid(ns), sid(name))

    sdata = bytearray()
    offs = []
    for x in pool:
        offs.append(len(sdata))
        sdata += struct.pack("<H", len(x)) + x.encode("utf-16le") + b"\x00\x00"
    while len(sdata) % 4:
        sdata += b"\x00"
    strings_start = 28 + 4 * len(pool)
    pool_chunk = struct.pack("<HHIIIIII", 0x0001, 28, strings_start + len(sdata),
                             len(pool), 0, 0, strings_start, 0)
    pool_chunk += struct.pack("<%dI" % len(offs), *offs) + bytes(sdata)

    res_chunk = struct.pack("<HHI", 0x0180, 8, 8 + 4 * n_res)
    res_chunk += struct.pack("<%dI" % n_res, *resmap)

    total = 8 + len(pool_chunk) + len(res_chunk) + len(body)
    return struct.pack("<HHI", 0x0003, 8, total) + pool_chunk + res_chunk + bytes(body)


def clean_manifest(data):
    events, name_ids = parse_axml(data)
    out = []
    for e in events:
        if e[0] == "start":
            attrs = [a for a in e[4] if a[1] not in DROP_ATTRS]
            out.append(("start", e[1], e[2], e[3], attrs))
        else:
            out.append(e)
    return build_axml(out, name_ids)


# ------------------------------------------------------------------- signing

def sha1b64(b):
    return base64.b64encode(hashlib.sha1(b).digest()).decode("ascii")


def make_signature_files(files):
    mf = b"Manifest-Version: 1.0\r\nCreated-By: 1.0 (Android)\r\n\r\n"
    sections = []
    for name, data in files:
        sec = ("Name: %s\r\nSHA1-Digest: %s\r\n\r\n" % (name, sha1b64(data))).encode()
        sections.append((name, sec))
        mf += sec
    sf = ("Signature-Version: 1.0\r\nCreated-By: 1.0 (Android)\r\n"
          "SHA1-Digest-Manifest: %s\r\n\r\n" % sha1b64(mf)).encode()
    for name, sec in sections:
        sf += ("Name: %s\r\nSHA1-Digest: %s\r\n\r\n" % (name, sha1b64(sec))).encode()
    return mf, sf


def sign_pkcs7(sf_bytes, cert, key, workdir):
    sf_path = os.path.join(workdir, "CERT.SF.tmp")
    with open(sf_path, "wb") as f:
        f.write(sf_bytes)
    return subprocess.run(
        ["openssl", "smime", "-sign", "-binary", "-noattr", "-md", "sha1",
         "-signer", cert, "-inkey", key, "-in", sf_path, "-outform", "DER"],
        check=True, stdout=subprocess.PIPE).stdout


# ---------------------------------------------------------------------- main

def add(z, name, data):
    zi = zipfile.ZipInfo(name, date_time=(2020, 1, 1, 0, 0, 0))
    zi.compress_type = zipfile.ZIP_DEFLATED
    zi.create_system = 0
    zi.external_attr = 0
    z.writestr(zi, data)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--manifest-from", required=True, help="aapt が作った APK/zip")
    ap.add_argument("--dex", required=True)
    ap.add_argument("--cert", required=True)
    ap.add_argument("--key", required=True)
    ap.add_argument("--out", required=True)
    ap.add_argument("--clean-manifest", action="store_true")
    a = ap.parse_args()

    with zipfile.ZipFile(a.manifest_from) as z:
        manifest = z.read("AndroidManifest.xml")
    if a.clean_manifest:
        manifest = clean_manifest(manifest)
    with open(a.dex, "rb") as f:
        dex = f.read()

    files = [("AndroidManifest.xml", manifest), ("classes.dex", dex)]
    mf, sf = make_signature_files(files)
    rsa = sign_pkcs7(sf, a.cert, a.key, os.path.dirname(os.path.abspath(a.out)))

    with zipfile.ZipFile(a.out, "w") as z:
        for name, data in files:
            add(z, name, data)
        add(z, "META-INF/MANIFEST.MF", mf)
        add(z, "META-INF/CERT.SF", sf)
        add(z, "META-INF/CERT.RSA", rsa)
    print("wrote %s (%d bytes, clean_manifest=%s)" % (
        a.out, os.path.getsize(a.out), a.clean_manifest))


if __name__ == "__main__":
    sys.exit(main())
