#!/usr/bin/env bash
# Android 1.0 (API 1) 向け APK をコマンドラインだけでビルドする。
# Gradle は使わず、aapt / javac / d8 / zipalign / apksigner を直接呼ぶ。
set -euo pipefail
cd "$(dirname "$0")"

SDK="${ANDROID_HOME:-${ANDROID_SDK_ROOT:-/usr/local/lib/android/sdk}}"
echo "SDK: $SDK"

# --- 最新のプラットフォームJarを選ぶ (コンパイル用のスタブとして使うだけ) ---
PL=$(ls -1 "$SDK/platforms" | grep -E '^android-[0-9]+$' | sort -V | tail -1)
JAR="$SDK/platforms/$PL/android.jar"
[ -f "$JAR" ] || { echo "android.jar not found"; exit 1; }
echo "platform: $PL"

# --- d8 と apksigner を持つ最新の build-tools を選ぶ ---
BT=""
for v in $(ls -1 "$SDK/build-tools" | grep -E '^[0-9]+(\.[0-9]+)*$' | sort -V -r); do
  if [ -x "$SDK/build-tools/$v/d8" ] && [ -x "$SDK/build-tools/$v/apksigner" ]; then
    BT="$SDK/build-tools/$v"
    break
  fi
done
[ -n "$BT" ] || { echo "usable build-tools not found"; exit 1; }
echo "build-tools: $BT"

rm -rf build
mkdir -p build/classes build/dex

# --- 1. マニフェストをパッケージ化 (リソースは使わない) ---
# 旧形式の aapt を優先し、文字列プールは UTF-16 にする (古い端末向け)。
# aapt が無い/失敗した場合のみ aapt2 にフォールバックする。
if [ -x "$BT/aapt" ] && "$BT/aapt" package -f --utf16 \
      -M AndroidManifest.xml -I "$JAR" -F build/base.apk \
      --min-sdk-version 1 --version-code 1 --version-name 1.0; then
  echo "packaged with aapt"
else
  echo "aapt failed or missing; falling back to aapt2"
  rm -f build/base.apk
  "$BT/aapt2" link -o build/base.apk -I "$JAR" \
      --manifest AndroidManifest.xml \
      --min-sdk-version 1 --target-sdk-version 1 \
      --version-code 1 --version-name 1.0
fi

# --- 2. Java をコンパイル (Java 8 バイトコード、ラムダ等は使っていない) ---
javac --release 8 -Xlint:-options -classpath "$JAR" -d build/classes \
      $(find src -name '*.java')

# --- 3. dex に変換 (min-api 1) ---
if ! "$BT/d8" --release --min-api 1 --lib "$JAR" --output build/dex \
      $(find build/classes -name '*.class'); then
  echo "d8 rejected --min-api 1; retrying with 3"
  rm -rf build/dex && mkdir -p build/dex
  "$BT/d8" --release --min-api 3 --lib "$JAR" --output build/dex \
      $(find build/classes -name '*.class')
fi

# --- 4. classes.dex を APK に追加 ---
cp build/base.apk build/unsigned.apk
(cd build/dex && zip -q ../unsigned.apk classes.dex)

# --- 5. アラインして署名 (デバッグ鍵を毎回生成) ---
"$BT/zipalign" -f 4 build/unsigned.apk build/aligned.apk
keytool -genkeypair -keystore build/debug.keystore \
    -storepass android -keypass android -alias deskclock \
    -keyalg RSA -keysize 2048 -validity 10000 \
    -dname "CN=DeskClock,O=Debug,C=JP" >/dev/null 2>&1
"$BT/apksigner" sign --ks build/debug.keystore \
    --ks-pass pass:android --key-pass pass:android \
    --min-sdk-version 1 \
    --out build/DeskClock.apk build/aligned.apk
"$BT/apksigner" verify --verbose build/DeskClock.apk || true

ls -l build/DeskClock.apk
echo "OK: build/DeskClock.apk"
