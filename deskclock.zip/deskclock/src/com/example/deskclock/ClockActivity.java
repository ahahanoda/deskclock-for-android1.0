package com.example.deskclock;

import android.app.Activity;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.Window;
import android.view.WindowManager;

/**
 * 卓上時計。Android 1.0 (API 1) に存在するAPIだけを使う。
 * 画面タップ または メニューキーで操作する。
 */
public class ClockActivity extends Activity {

    private static final String PREFS = "deskclock";
    private static final int MENU_MODE = 1;
    private static final int MENU_24H = 2;
    private static final int MENU_SEC = 3;
    private static final int MENU_BRIGHT = 4;

    // 画面の明るさ: 端末既定(-1) → 明るい → 中 → 暗い
    private static final float[] BRIGHTNESS = { -1f, 1.0f, 0.5f, 0.15f };

    private ClockView view;
    private int brightIndex = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        requestWindowFeature(Window.FEATURE_NO_TITLE);
        getWindow().setFlags(
                WindowManager.LayoutParams.FLAG_FULLSCREEN
                        | WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON,
                WindowManager.LayoutParams.FLAG_FULLSCREEN
                        | WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);

        view = new ClockView(this);
        SharedPreferences p = getSharedPreferences(PREFS, MODE_PRIVATE);
        view.setDigital(p.getBoolean("digital", false));
        view.setUse24h(p.getBoolean("h24", true));
        view.setShowSeconds(p.getBoolean("seconds", true));
        brightIndex = p.getInt("bright", 0);
        if (brightIndex < 0 || brightIndex >= BRIGHTNESS.length) {
            brightIndex = 0;
        }
        applyBrightness();

        setContentView(view);
    }

    @Override
    protected void onResume() {
        super.onResume();
        view.start();
    }

    @Override
    protected void onPause() {
        super.onPause();
        view.stop();
        SharedPreferences.Editor e = getSharedPreferences(PREFS, MODE_PRIVATE).edit();
        e.putBoolean("digital", view.isDigital());
        e.putBoolean("h24", view.isUse24h());
        e.putBoolean("seconds", view.isShowSeconds());
        e.putInt("bright", brightIndex);
        e.commit();
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        menu.add(0, MENU_MODE, 0, "Analog / Digital");
        menu.add(0, MENU_24H, 1, "12h / 24h");
        menu.add(0, MENU_SEC, 2, "Seconds on/off");
        menu.add(0, MENU_BRIGHT, 3, "Brightness");
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case MENU_MODE:
                view.setDigital(!view.isDigital());
                return true;
            case MENU_24H:
                view.setUse24h(!view.isUse24h());
                return true;
            case MENU_SEC:
                view.setShowSeconds(!view.isShowSeconds());
                return true;
            case MENU_BRIGHT:
                brightIndex = (brightIndex + 1) % BRIGHTNESS.length;
                applyBrightness();
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }

    private void applyBrightness() {
        WindowManager.LayoutParams lp = getWindow().getAttributes();
        lp.screenBrightness = BRIGHTNESS[brightIndex];
        getWindow().setAttributes(lp);
    }
}
