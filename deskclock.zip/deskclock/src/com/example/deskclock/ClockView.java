package com.example.deskclock;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Typeface;
import android.os.Handler;
import android.view.MotionEvent;
import android.view.View;

import java.util.Calendar;

/**
 * アナログ/デジタルを切り替えて表示する時計View。
 * Android 1.0 (API 1) にあるクラス・メソッドだけを使用している。
 */
public class ClockView extends View {

    private static final String[] WEEKDAYS = {
            "SUN", "MON", "TUE", "WED", "THU", "FRI", "SAT"
    };

    private static final int COLOR_BG = 0xFF000000;
    private static final int COLOR_FACE = 0xFF101418;
    private static final int COLOR_MAIN = 0xFFEEEEEE;
    private static final int COLOR_SUB = 0xFF9AA0A6;
    private static final int COLOR_SEC = 0xFFFF6B6B;

    private boolean digital = false;
    private boolean use24h = true;
    private boolean showSeconds = true;

    private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Handler handler = new Handler();
    private boolean running = false;

    private final Runnable ticker = new Runnable() {
        public void run() {
            if (!running) {
                return;
            }
            invalidate();
            long now = System.currentTimeMillis();
            // 次の「秒」の少し後に再描画する
            handler.postDelayed(this, 1000 - (now % 1000) + 5);
        }
    };

    public ClockView(Context context) {
        super(context);
    }

    // ---- 設定 ----------------------------------------------------------

    public boolean isDigital() { return digital; }
    public boolean isUse24h() { return use24h; }
    public boolean isShowSeconds() { return showSeconds; }

    public void setDigital(boolean v) { digital = v; invalidate(); }
    public void setUse24h(boolean v) { use24h = v; invalidate(); }
    public void setShowSeconds(boolean v) { showSeconds = v; invalidate(); }

    public void start() {
        if (running) {
            return;
        }
        running = true;
        handler.post(ticker);
    }

    public void stop() {
        running = false;
        handler.removeCallbacks(ticker);
    }

    // ---- 操作: タップでアナログ/デジタル切り替え ---------------------

    @Override
    public boolean onTouchEvent(MotionEvent event) {
        int action = event.getAction();
        if (action == MotionEvent.ACTION_DOWN) {
            return true;
        }
        if (action == MotionEvent.ACTION_UP) {
            setDigital(!digital);
            return true;
        }
        return super.onTouchEvent(event);
    }

    // ---- 描画 --------------------------------------------------------

    @Override
    protected void onDraw(Canvas canvas) {
        canvas.drawColor(COLOR_BG);
        int w = getWidth();
        int h = getHeight();
        Calendar t = Calendar.getInstance();
        if (digital) {
            drawDigital(canvas, t, w, h);
        } else {
            drawAnalog(canvas, t, w, h);
        }
    }

    private static String two(int n) {
        return n < 10 ? "0" + n : Integer.toString(n);
    }

    private static String dateText(Calendar t) {
        return WEEKDAYS[t.get(Calendar.DAY_OF_WEEK) - 1] + "  "
                + t.get(Calendar.YEAR) + "/"
                + two(t.get(Calendar.MONTH) + 1) + "/"
                + two(t.get(Calendar.DAY_OF_MONTH));
    }

    private void drawRadial(Canvas c, float cx, float cy,
                            float from, float to, float deg) {
        double a = Math.toRadians(deg);
        float s = (float) Math.sin(a);
        float co = (float) Math.cos(a);
        c.drawLine(cx + from * s, cy - from * co, cx + to * s, cy - to * co, paint);
    }

    private void drawAnalog(Canvas c, Calendar t, int w, int h) {
        float cx = w / 2f;
        float cy = h / 2f;
        float r = Math.min(w, h) / 2f * 0.92f;

        int hour = t.get(Calendar.HOUR);          // 0-11
        int min = t.get(Calendar.MINUTE);
        int sec = t.get(Calendar.SECOND);

        // 文字盤
        paint.setStyle(Paint.Style.FILL);
        paint.setColor(COLOR_FACE);
        c.drawCircle(cx, cy, r, paint);
        paint.setStyle(Paint.Style.STROKE);
        paint.setStrokeWidth(r * 0.03f);
        paint.setColor(0xFFDDDDDD);
        c.drawCircle(cx, cy, r, paint);

        // 目盛り
        paint.setStrokeCap(Paint.Cap.BUTT);
        for (int i = 0; i < 60; i++) {
            boolean big = (i % 5 == 0);
            float len = big ? r * 0.10f : r * 0.04f;
            paint.setStrokeWidth(big ? r * 0.025f : r * 0.010f);
            paint.setColor(big ? 0xFFFFFFFF : 0xFF888888);
            drawRadial(c, cx, cy, r * 0.95f - len, r * 0.95f, i * 6f);
        }

        // 数字
        paint.setStyle(Paint.Style.FILL);
        paint.setTextAlign(Paint.Align.CENTER);
        paint.setTypeface(Typeface.DEFAULT_BOLD);
        float numSize = r * 0.16f;
        paint.setTextSize(numSize);
        paint.setColor(COLOR_MAIN);
        for (int n = 1; n <= 12; n++) {
            double a = Math.toRadians(n * 30);
            float px = cx + (float) (r * 0.72f * Math.sin(a));
            float py = cy - (float) (r * 0.72f * Math.cos(a)) + numSize * 0.35f;
            c.drawText(Integer.toString(n), px, py, paint);
        }

        // 日付
        paint.setTypeface(Typeface.DEFAULT);
        paint.setTextSize(r * 0.09f);
        paint.setColor(COLOR_SUB);
        c.drawText(dateText(t), cx, cy + r * 0.42f, paint);

        // 針
        paint.setStyle(Paint.Style.STROKE);
        paint.setStrokeCap(Paint.Cap.ROUND);

        float hourDeg = (hour + min / 60f) * 30f;
        float minDeg = (min + sec / 60f) * 6f;
        float secDeg = sec * 6f;

        paint.setColor(0xFFFFFFFF);
        paint.setStrokeWidth(r * 0.045f);
        drawRadial(c, cx, cy, 0f, r * 0.50f, hourDeg);
        paint.setStrokeWidth(r * 0.030f);
        drawRadial(c, cx, cy, 0f, r * 0.75f, minDeg);

        if (showSeconds) {
            paint.setColor(COLOR_SEC);
            paint.setStrokeWidth(r * 0.012f);
            drawRadial(c, cx, cy, -r * 0.15f, r * 0.85f, secDeg);
        }

        // 中心の点
        paint.setStyle(Paint.Style.FILL);
        paint.setColor(showSeconds ? COLOR_SEC : 0xFFFFFFFF);
        c.drawCircle(cx, cy, r * 0.03f, paint);
    }

    private void drawDigital(Canvas c, Calendar t, int w, int h) {
        int hour = t.get(Calendar.HOUR_OF_DAY);
        int min = t.get(Calendar.MINUTE);
        int sec = t.get(Calendar.SECOND);

        String ampm = null;
        String hourText;
        if (use24h) {
            hourText = two(hour);
        } else {
            ampm = hour < 12 ? "AM" : "PM";
            int h12 = hour % 12;
            if (h12 == 0) {
                h12 = 12;
            }
            hourText = Integer.toString(h12);
        }
        String main = hourText + ":" + two(min);

        paint.setStyle(Paint.Style.FILL);
        paint.setTextAlign(Paint.Align.CENTER);
        paint.setTypeface(Typeface.create(Typeface.MONOSPACE, Typeface.BOLD));

        // 幅に収まる大きさを求める(桁数が変わっても大きさが揺れないよう固定文字列で測る)
        paint.setTextSize(100f);
        float w0 = paint.measureText("88:88");
        float size = 100f * (w * 0.88f) / w0;
        float maxByHeight = h * 0.42f;
        if (size > maxByHeight) {
            size = maxByHeight;
        }

        float cx = w / 2f;
        float baseline = h / 2f + size * 0.20f;

        // 時刻
        paint.setTextSize(size);
        paint.setColor(COLOR_MAIN);
        c.drawText(main, cx, baseline, paint);

        // 日付 (+ AM/PM)
        paint.setTypeface(Typeface.DEFAULT);
        paint.setTextSize(size * 0.22f);
        paint.setColor(COLOR_SUB);
        String dateLine = dateText(t);
        if (ampm != null) {
            dateLine = dateLine + "   " + ampm;
        }
        c.drawText(dateLine, cx, baseline - size * 0.85f, paint);

        // 秒
        if (showSeconds) {
            paint.setTypeface(Typeface.create(Typeface.MONOSPACE, Typeface.BOLD));
            paint.setTextSize(size * 0.32f);
            paint.setColor(COLOR_SEC);
            c.drawText(two(sec), cx, baseline + size * 0.50f, paint);
        }
    }
}
